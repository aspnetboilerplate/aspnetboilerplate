# bower-abp-resources
Bower package for ASP.NET Boilerplate web script and style resources.

## Installation
Via bower:
```bash
bower install abp-web-resources --save
```
