﻿(function ($) {

    $(function() {
        //...
    });

})(jQuery);