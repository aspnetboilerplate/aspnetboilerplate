﻿namespace Acme.SimpleTaskApp.Web.Startup
{
    public class PageNames
    {
        public const string Home = "Home";
        public const string About = "About";
        public const string TaskList = "TaskList";
    }
}
