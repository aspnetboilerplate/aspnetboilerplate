namespace Acme.SimpleTaskApp.Web.Controllers
{
    public class LayoutController : SimpleTaskAppControllerBase
    {

    }
}