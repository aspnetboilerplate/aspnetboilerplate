﻿namespace Acme.SimpleTaskApp.Tasks
{
    public enum TaskState : byte
    {
        Open = 0,
        Completed = 1
    }
}