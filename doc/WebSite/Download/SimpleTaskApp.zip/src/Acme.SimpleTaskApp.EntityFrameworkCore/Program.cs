﻿namespace Acme.SimpleTaskApp
{
    /* WORKAROUND
     * This is needed since .NET CLI does not support class library projects!     
     * See https://docs.efproject.net/en/latest/cli/dotnet.html#preview-1-known-issues
     */
    public class Program
    {
        public static void Main()
        {
            
        }
    }
}
