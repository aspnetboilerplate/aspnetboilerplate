﻿namespace Reation.CMS
{
    public class CMSConsts
    {
        public const string LocalizationSourceName = "CMS";
    }
}