using System.Data.Entity.Migrations;

namespace Reation.CMS.Migrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<CMS.EntityFramework.CMSDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "CMS";
        }

        protected override void Seed(CMS.EntityFramework.CMSDbContext context)
        {
            // This method will be called every time after migrating to the latest version.
            // You can add any seed data here...
        }
    }
}
