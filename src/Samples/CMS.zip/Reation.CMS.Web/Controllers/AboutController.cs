﻿using System.Web.Mvc;

namespace Reation.CMS.Web.Controllers
{
    public class AboutController : CMSControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}